BOARD DIMENSIONS:   1.53x2.26"
BOARD THICKNESS:    0.062"
COPPER WEIGHT:      1 oz.
TRACE/SPACE:        > 7 mil
MIN HOLE DIA:       37 mil
SOLDER MASK SIDES:  Both
SOLDER MASK COLOR:  White
SILKSCREEN SIDES:   Top Only
SILKSCREEN COLOR:   Black
FINISH:             Immersion Silver
PANELIZATION:       Individual